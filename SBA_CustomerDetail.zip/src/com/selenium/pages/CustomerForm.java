package com.selenium.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class CustomerForm {
	WebDriver driver;
	By customerName=By.name("cname");
	By cage = By.name("age");
	By caddress = By.name("address");
	By cphonenumber = By.name("phonenumber");
	By cemail = By.name("email");
	
	public void setCustomerName(String cName)
	{
		driver.findElement(customerName).sendKeys(cName);
	}

	public void setAge(String age)
	{
		driver.findElement(cage).sendKeys(age);
	}
	
	public void setAddress(String address)
	{
		driver.findElement(caddress).sendKeys(address);
	}

	public void setPhoneNumber(String phoneNumber)
	{
		driver.findElement(cphonenumber).sendKeys(phoneNumber);
	}
	
	public void setEmail(String email)
	{
		driver.findElement(cemail).sendKeys(email);
	}
	
	
	public String getErrorMessage() {
		return driver.findElement(By.id("errorMessage")).getText();
	}

	public void submitForm() {
		driver.findElement(By.id("submit")).click();
	}

	
	
	
	
	public CustomerForm(WebDriver driver) {
		this.driver=driver;
	}
	// fill the code
}
