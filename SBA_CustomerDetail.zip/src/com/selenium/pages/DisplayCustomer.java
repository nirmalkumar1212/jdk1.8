package com.selenium.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class DisplayCustomer {
	
	By title = By.xpath("/html/body/h2");
	By name = By.xpath("/html/body/table/tbody/tr[1]/td[2]");
	By age=By.xpath("/html/body/table/tbody/tr[2]/td[2]");
	By address=By.xpath("/html/body/table/tbody/tr[3]/td[2]");
	By email=By.xpath("/html/body/table/tbody/tr[5]/td[2]");
	By phonenumber=By.xpath("/html/body/table/tbody/tr[4]/td[2]");
	
	WebDriver driver;

	public String getTitle()
	{
		return driver.findElement(By.xpath("/html/body/h2")).getText();
		
	}
	
	public String getName()
	{
		return driver.findElement(By.xpath("/html/body/table/tbody/tr[1]/td[2]")).getText();
		
	}
	
	public String getAge()
	{
		return driver.findElement(By.xpath("/html/body/table/tbody/tr[2]/td[2]")).getText();
		
	}
	
	public String getEmail()
	{
		return driver.findElement(By.xpath("/html/body/table/tbody/tr[5]/td[2]")).getText();
		
	}
	
	public String getAddress()
	{
		return driver.findElement(By.xpath("/html/body/table/tbody/tr[3]/td[2]")).getText();
		
	}
	
	public String getPhoneNumber()
	{
		return driver.findElement(By.xpath("/html/body/table/tbody/tr[4]/td[2]")).getText();
		
	}
	
		
	public DisplayCustomer(WebDriver driver) {
		
		this.driver=driver;
	}
		// fill the code
	
}
