package com.selenium.setup;



import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {
    private static XSSFSheet ExcelWSheet;
	private static XSSFWorkbook ExcelWBook;
	private static XSSFRow Row;
	private static FileInputStream excelFile;
	private static String filePath;



@SuppressWarnings("null")
public static Object[][] readExcelData(String sheetName) throws Exception {
	
	Object[][] arrayExcelData = null;
	ArrayList<Object> mydata = new ArrayList<Object>();
	 String cname = null;
	
			String workingDir = System.getProperty("user.dir");
			filePath = workingDir+File.separator+"src"+File.separator+"customer_registration.xlsx";
			excelFile = new FileInputStream(filePath);
            ExcelWBook = new XSSFWorkbook(excelFile);
		    ExcelWSheet = ExcelWBook.getSheet(sheetName);		    
		    Row = ExcelWSheet.getRow(1);
			int RowCount= ExcelWSheet.getLastRowNum();
			int columnCount = Row.getLastCellNum();
			arrayExcelData = new Object[RowCount][columnCount];
			for(int i =0;i<RowCount;i++) {
			  for(int j =0;j<columnCount;j++) {
				  
				  arrayExcelData[i][j] =ExcelWSheet.getRow(i+1).getCell(j).getStringCellValue();
			  }
			}
			
			System.out.println(arrayExcelData);
					
			//mydata.add(new Object[]{arrayExcelData});
			
		    
		    
		    return arrayExcelData;

}








}
